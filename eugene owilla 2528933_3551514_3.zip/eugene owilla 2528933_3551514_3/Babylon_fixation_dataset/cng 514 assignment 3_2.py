# part 2 - clustering
import glob
import os

import pandas as pd
from PIL import Image
from pandas import DataFrame
from sklearn.cluster import DBSCAN
import numpy
from matplotlib import pyplot as plt
from matplotlib.pyplot import figure, imread

directory = '.'


def text_to_csv():
    # iterate through all file and convert to txt to csv
    for filename in os.listdir(directory):
        # filename = 'P-1.txt'

        if filename.endswith('.txt'):
            print(filename)

            # get file name without extension
            my_filename = filename.split('.')[0]

            # open txt file in read mode
            input_file = open(filename, "r")

            # create csv output file name to write
            output_file_name = my_filename + ".csv"
            output_file = open(output_file_name, "w+")

            for f in input_file:
                output_file.write(f.replace("\t", ","))

            output_file.close()
            input_file.close()


def csv_to_dataframe():
    # read all csv files into dataframe and return df
    df = []
    print(os.listdir(directory))

    for this_file in os.listdir(directory):
        # filename = 'P-xx.csv'
        try:
            if len(this_file) <= 8 and this_file.endswith('.csv'):
                # print(this_file)
                # append data from this csv file to data frame
                df2 = pd.read_csv(this_file, header=0)
                df.append(df2)
        except:
            pass

    # concat
    df = pd.concat(df)
    # print(df)
    return df


def visualize_plot(my_dataframe_numpy, my_cluster):
    df = DataFrame(dict(x=my_dataframe_numpy[:, 0], y=my_dataframe_numpy[:, 1], label=my_cluster))
    # colors = {-1: 'red', }
    fig, ax = plt.subplots(figsize=(8, 8))

    # resize segmented png file - 1280x1024, 960x840
    image = Image.open('BABYLON_segmented.png')
    new_image = image.resize((1280, 1024))
    new_image.save('BABYLON_segmented.png')

    my_image = imread("BABYLON_segmented.png")
    ax.imshow(my_image)

    grouped = df.groupby('label')
    for key, group in grouped:
        group.plot(ax=ax, kind='scatter', x='x', y='y', label=key)

    # label axes
    plt.xlabel('fixation_point_x')
    plt.ylabel('fixation_point_y')

    # color-separating the clusters by plotting each cluster in a separate frame.
    plt.scatter(df['x'], df['y'], c=df['label'])

    # removing key
    ax.get_legend().remove()

    # showing the plot
    plt.show()


if __name__ == "__main__":
    # text to csv, csv to df for manipulation
    print(f'getting data frame...')

    # text to csv,
    # text_to_csv()

    # csv to df
    my_dataframe = csv_to_dataframe()
    print(my_dataframe)

    #
    my_dataframe = my_dataframe.drop(columns=['FixationIndex', 'Timestamp', 'FixationDuration', 'StimuliName'])

    # get clustering from dbscan
    clustering = DBSCAN(eps=30, min_samples=15).fit(my_dataframe.to_numpy())
    cluster = clustering.labels_
    print(f'clusters: {len(set(cluster))}, results: {cluster}')

    # visual the data in a plot
    visualize_plot(my_dataframe.to_numpy(), cluster)

    print("done")
