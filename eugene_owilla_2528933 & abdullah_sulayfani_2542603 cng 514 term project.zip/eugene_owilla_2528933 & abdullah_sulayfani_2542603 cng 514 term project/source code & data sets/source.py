#Abdullah Sulayfani 2542603
#Eugene Owilla 2528933

# WARNING: The code uses polynomial regression with degree = 10. It takes a very long time to execute.
# It took 10-15~ minutes to execute on a 10th generation Core i7 processor and it consumed 5~8 Gbs of RAM.
# The polynomial regression code snippet is at the end of the file. 
# You can comment it if you wanted to run the code and get quick results from the other algorithms


from copy import copy
import pandas
import matplotlib.pyplot as plot
import numpy as np
from sklearn import preprocessing
import math
from sklearn.metrics import accuracy_score
from sklearn.svm import SVR
from sklearn.metrics import r2_score,mean_squared_error
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
import statsmodels.api as sm



#Please note that if you intend on compiling and running the code on your machine then you need to modify the file path below.
dataset = pandas.read_csv("C:/Abood/Metu NCC/Masters/1st Semester/CNG514/Project/metu-ncc-cng514-challenge/ads_dataset.csv", index_col='ad_id')
tweets = pandas.read_csv("C:/Abood/Metu NCC/Masters/1st Semester/CNG514/Project/metu-ncc-cng514-challenge/tweets.csv")


#Created copies of the original sets to have more editing freedom
ads_dataset = dataset.copy()


#Checking if the dataset contains empty fields
result = np.where(pandas.isnull(ads_dataset))
if(len(result[0]) > 0):
    print("\nThe ads_dataset set contains empty fields.\n")
else:
    print("\nThe ads_dataset contains no empty fields.\n")

#We detected one row in the "m2" column that had a string value. We dropped that row.
ads_dataset = ads_dataset.drop(index=20416041)
ads_dataset['m2'] = pandas.to_numeric(ads_dataset['m2'])

#We plotted the boxplots and found that there is one high value outlier in the m2 column
print("\nThe m2 max value:")
print(ads_dataset.loc[ads_dataset['m2'].idxmax()])
#We got the index from the print statement above and dropped that row
ads_dataset = ads_dataset.drop(index=33516246)


#Printing the datatypes to make sure there are no problems with any columns
print('\nThe ads_dataset set datatypes are:')
print(ads_dataset.dtypes)

#Getting all values in the 'type' column
type_column = ads_dataset.loc[:,'type'].to_numpy(copy=True)

#Encoding the 'type' column values so they end up in numeric format (required by the libraries we will use).
encoder = preprocessing.LabelEncoder()
type_column = encoder.fit_transform(type_column)

#Assigning the encoded values to the 'type' column
ads_dataset['type'] = type_column


######################################################################################################
############################    Creating the 'trending_factor' feature    ############################
#Getting all unique quarter names from the tweets dataset
quarters = tweets['quarter_name'].unique()

dictionary = {}

#Creating and initializing a dictionary with the quarter names as keys
for i in quarters:
    dictionary[i] = None

#The loop below will count in how many tweets each quarter was mentioned and assign that value to the dictionary.
count = 0
for key in dictionary:
    count = len(tweets.loc[(tweets['quarter_name'] == key)])
    dictionary[key] = count

#Creating a new column called 'trending_factor' that adds the number of tweets the quarter in which the estate is located was mentioned.
ads_dataset['trending_factor'] = np.nan
ads_dataset['trending_factor'] = ads_dataset['quarter_name'].apply(lambda x: dictionary.get(x, 0))

######################################################################################################
######################################################################################################


######################################################################################################
############################    Creating the 'rooms' feature    ######################################

#Creating a new empty column
ads_dataset['rooms'] = ''

#The loop below takes each ad_title and extracts the room layout by first locating the '+' character and then takes the adjacent numbers
for i in ads_dataset.index:
    start_index = -1
    layout = str(ads_dataset['ad_title'][i])
    start_index = layout.find('+')

    if start_index >= 0:
        ads_dataset.at[i, 'rooms'] = layout[(start_index-1):(start_index+2)]

#Now that we have the new rooms layout column, we encoded it (required by the libraries we will use).
rooms = ads_dataset.loc[:,'rooms'].to_numpy(copy=True)
encoder = preprocessing.LabelEncoder()
rooms = encoder.fit_transform(rooms)

#We assigned values to the 'rooms' column
ads_dataset['rooms'] = rooms

#Some advertisements had no room layout in them so we divided the set into two.
#The encoder assigned a value of 0 to rows where the room layout value was an empty string.
with_layout = ads_dataset.loc[(ads_dataset['rooms'] != 0)]
no_layout = ads_dataset.loc[(ads_dataset['rooms'] == 0)]

#We will try to predict the missing room layouts using the following training columns
trainingColumns = ['lat', 'lng', 'm2', 'type', 'population', 'price']
predictedColumns = ['rooms']

x_train = with_layout[trainingColumns]
y_train = with_layout.loc[:, 'rooms'].to_numpy(copy=True)

x_test = no_layout[trainingColumns]

#We used KNN because we thought of room layouts as categories. And we want to assign each estate to its category.
model = KNeighborsClassifier(n_neighbors=3)
model.fit(x_train,y_train)

#We assign the predicted room layouts to the dataset that contains no layouts.
y_predicted = model.predict(x_test)
no_layout['rooms'] = y_predicted

#We merge back the two sets.
combined = [with_layout, no_layout]
ads_dataset = pandas.concat(combined)

######################################################################################################
######################################    Checking price outliers    #################################

#Other than the single outlier we detected in the 'm2' column earlier, this dataset had no unrealistic outliers.
#The dataset consists of real data. Meaning that it is very possible to have very expensive prices for example.
#To showcase that, we used Interquartile Range(IQR) method to detect the outliers for 'price' column.
#We printed those outliers and visually inspected them and found them to be realistic.

#First we calculate the quartiles.
quantiles = ads_dataset['price'].quantile([0.25, 0.50, 0.75])
print("\nQuartiles are: ")
print(quantiles)

quantiles = quantiles.to_numpy(copy=True)

#We create the necessary variables that we will need for the IQR formula
Q1 = quantiles[0]
Q3 = quantiles[2]

IQR = (Q3 - Q1)
bias = 2

#Any value above the lower/upper threshold will be considered an outlier.
upperThreshold = Q3 + (bias * IQR)
lowerThreshold = Q1 - (bias * IQR)

#We printed the values and found them realistic.
print("\nThe price outliers (low values):")
print(ads_dataset.loc[(ads_dataset['price'] < lowerThreshold)])

print("\nThe price outliers (high values):")
print(ads_dataset.loc[(ads_dataset['price'] > upperThreshold)])
######################################################################################################
######################################################################################################

######################################################################################################
######################################    Finding The Correlation    #################################
print("\n")
print("Correlation Matrix: ")
print(ads_dataset.corr())
print("\n")
######################################################################################################
######################################################################################################


######################################################################################################
############################    Preparing the training and testing sets    ###########################
#Getting the indices of the dataset
Indices = ads_dataset.index

#Creating two sets that do not overlap. A training set (2/3 of the original set) and a testing set (1/3 of the original set)
testingSetSize = math.floor(len(ads_dataset)/3)

testingSet = ads_dataset.loc[Indices[1:testingSetSize]]
trainingSet = ads_dataset.loc[Indices[testingSetSize:]]

#Specifying the training columns (we only picked the relevant ones)
trainingColumns = ['lat', 'lng', 'm2', 'type', 'population', 'trending_factor', 'rooms']
predictedColumns = ['price']

x_train = trainingSet[trainingColumns]
y_train = trainingSet.loc[:, 'price'].to_numpy(copy=True)

x_test = testingSet[trainingColumns]
y_test = testingSet.loc[:, 'price'].to_numpy(copy=True)
######################################################################################################
######################################################################################################


######################################################################################################
#################################    Support Vector Regression     ###################################

#Creating the model and using it to predict the price for x_test
SVR_Model = SVR()
SVR_Model.fit(x_train,y_train)

y_predicted = SVR_Model.predict(x_test)

print("\nSVR Prediction Results: ")
print(y_predicted)

#Throughout this project, we will use Root Mean Square Error(RMSE) method to measure the effectiveness of our models
#Typical accuracy measures cannot be used with regression algorithms
score = np.sqrt(((y_predicted - y_test) ** 2).mean())
print("\nScore is: ")
print(score)
print("\n")

######################################################################################################
######################################################################################################


######################################################################################################
######################################    Random Forest    ###########################################

#Creating the model and using it to predict the price for x_test
regressor = RandomForestRegressor(n_estimators=20, random_state=0)
regressor.fit(x_train,y_train)

y_predicted = regressor.predict(x_test)

print("\nRandom-Forest Prediction Results: ")
print(y_predicted)

score = np.sqrt(((y_predicted - y_test) ** 2).mean())
print("\nScore is: ")
print(score)
print("\n")


######################################################################################################
######################################################################################################


######################################################################################################
######################################    Stepwise Regression    #####################################

#The stepwise algorithm has been explained in the report. But in short, we are supposed to print certain properties
#and based on those properties we drop a column then do linear regression. We repeat this process until we no longer
#need to drop any columns.
# 
# In our case, we did not need to drop any columns. So we directly moved to linear regression.
results = sm.OLS(y_train, x_train).fit()
print(results.summary())

######################################################################################################
######################################################################################################



######################################################################################################
######################################    Linear Regression    #######################################

linearRegressor = LinearRegression()

linearRegressor.fit(x_train, y_train)

y_predicted = linearRegressor.predict(x_test)

print("\nLinear-Regression Prediction Results: ")
print(y_predicted)

score = np.sqrt(((y_predicted - y_test) ** 2).mean())
print("\nScore is: ")
print(score)
print("\n")


######################################################################################################
######################################################################################################


######################################################################################################
######################################    Polynomial Regression    ###################################

#Using polynomial regression with degree 10. Please note that it takes a long time to execute.
polynomialRegressor = PolynomialFeatures(degree=10)

x_polly = polynomialRegressor.fit_transform(x_train)

Regressor = LinearRegression()
Regressor.fit(x_polly, y_train)

y_predicted = Regressor.predict(polynomialRegressor.fit_transform(x_test))

print("\nPolynomial-Regression Prediction Results: ")
print(y_predicted)

score = np.sqrt(((y_predicted - y_test) ** 2).mean())
print("\nScore is: ")
print(score)
print("\n")

######################################################################################################
######################################################################################################
"""

References:

1)	https://scikit-learn.org/stable/modules/preprocessing.html#preprocessing

2)	https://www.scipy.org/

3)	https://numpy.org/

4)	https://matplotlib.org/

5)  https://scikit-learn.org/stable/modules/neighbors.html

6)  https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html

7)  https://towardsdatascience.com/stepwise-regression-tutorial-in-python-ebf7c782c922

8)  https://towardsdatascience.com/machine-learning-polynomial-regression-with-python-5328e4e8a386

9)  https://medium.com/pursuitnotes/support-vector-regression-in-6-steps-with-python-c4569acd062d

10) https://scikit-learn.org/stable/modules/generated/sklearn.ensemble.RandomForestRegressor.html

11) https://online.stat.psu.edu/stat200/lesson/3/3.2

"""