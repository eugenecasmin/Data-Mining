# eugene casmin 252933 cng 514
import collections
import csv
from math import sqrt

import pandas as pd
import numpy as np
import statistics
from statistics import mode
import matplotlib.pyplot as plt


def find_range(val_list):
    min_val = 0  # should find the main value that is not 0
    s = set(val_list)
    min_val = sorted(s) [1]  # get 2nd smallest value

    max_val = max(val_list)

    result = (min_val, max_val)
    return result


def get_boxplot(data, label):  # data is an array, label is the attribute e.g., age
    fig = plt.figure(figsize=(10, 7))
    fig.suptitle('dispersion boxplot', fontsize=14, fontweight='bold')

    # Creating plot
    ax = fig.add_subplot(111)
    ax.boxplot(data)

    ax.set_ylabel(label)

    # show plot
    plt.show()


def get_histogram(data, label):
    # Creation of plot
    fig = plt.figure(figsize=(10, 5))

    # plotting the Histogram with certain intervals
    plt.hist(data, bins=[0, 15, 30, 45, 60, 75, 90, 105])

    # label axes
    plt.xlabel(label)
    plt.ylabel("frequencies")
    # Giving title to Histogram
    plt.title(label)

    # Displaying Histogram
    plt.show()


def get_scatter_plot(data, label):
    # get list of tuples of each age value and corresponding no. of occurrences
    occurrences = list(collections.Counter(data).items())

    # x - age values, y - no. of occurrences
    ages = []
    frequencies = []
    for x in occurrences:
        ages.append(x[0])

    for x in occurrences:
        frequencies.append(x[1])

    # label axes and title
    plt.xlabel(label)
    plt.ylabel("frequencies")
    plt.title(label + " distribution scatter plot")

    x = np.array(ages)
    y = np.array(frequencies)
    plt.scatter(x, y)

    plt.show()
    pass


def get_z_scores(data):  # returns a list of z scores of values in data
    result = []  # list to hold z scores of values in data

    for x in data:
        z_score = (x - np.mean(data)) / statistics.stdev(data)
        result.append(z_score)

    return result


def get_min_max_norm(data):  # returns a list of min max normalisation of values in data
    result = []  # list to hold min max norm values of values in data

    for x in data:
        min_max_norm = (x - np.min(data)) / (np.max(data) - np.min(data))
        result.append(min_max_norm)

    return result


def get_correlation(data_1, label_1, data_2, label_2):  # get correlation between two attributes. data_1 and data_2 are lists of values of two attributes

    numerator = 0  # to hold sum of all (xi - x.mean) * (yi - y.mean)
    denominator = 0  # to hold the square root of (sum of all (x_i - x.mean)^2 * sum of all (y_i - y.mean)^2)
    if len(data_1) == len(data_2):
        for i in range(len(data_1)):  # length of lists are equal
            numerator = numerator + ((data_1[i] - np.mean(data_1)) * (data_2[i] - np.mean(data_2)))

        sum_x = 0  # to hold sum of squares of (x_i - x.mean)
        sum_y = 0  # to hold sum of squares of (y_i - y.mean)

        for i in range(len(data_2)):
            sum_x = sum_x + ((data_1[i] - np.mean(data_1)) ** 2)
            sum_y = sum_y + ((data_2[i] - np.mean(data_2)) ** 2)

        denominator = sqrt(sum_x * sum_y)

    print(f'Correlation between {label_1} and {label_2} is {str(numerator / denominator)}')
    pass


if __name__ == "__main__":
    print("this is the main function.")
    print("to read an csv spreadsheet and convert to dictionary of dictionaries for manipulation..")

    filename = 'cng514-cancer-patient-data.csv'  # to hold excel spreadsheet name plus extension

    with open(filename, newline='') as f:
        reader = csv.reader(f)
        myData = list(reader)

    # convert list of lists to dictionary
    print("number of records in csv_reader: ", len(myData) - 1)

    patient_details = {}  # dictionary of type {patient: [patient details]}

    # iterate through myData; take first element of each list element as the key and the rest as a list as the value
    # split into keys and values
    keys = []  # will contain patient ids
    values = [[]]  # will be list of lists containing patient details

    # populating keys
    for element in myData:
        keys.append(element[0])

    # populating values
    for element in myData:
        values.append(element[1:])  # take all list elements except the first which is the key

    # create patient_details dictionary
    patient_details = dict(zip(keys, values))

    # we can now extract any field/s or record/s for manipulation
    # chosen attributes - age, weight and height.
    # we need a dict of type {'patientid': [list of patient ids], 'age': [list of ages], 'weight': [list of weights], 'height': [list of heights]}
    patient_id_list = keys[1:]
    age_list = []
    weight_list = []
    height_list = []

    # print("items: ", str(patient_details.items()))
    # populating the above lists
    for element in patient_details.items():
        if element[1]:  # if the array of elements is not empty.
            age_list.append(element[1][0])  # first item on details is 'age'
    age_list = age_list
    # print("ages: ", str(age_list), " no. of records: ", str(len(age_list)))

    for element in patient_details.items():
        if element[1]:
            weight_list.append(element[1][-1])  # last item on details is 'weight'
    weight_list = weight_list
    # print("weights: ", str(weight_list), " no. of records: ", str(len(weight_list)))

    for element in patient_details.items():
        if element[1]:
            height_list.append(element[1][-2])  # first item on details is 'age'
    height_list = height_list
    # print("heights: ", str(height_list), " no. of records: ", str(len(height_list)))

    # remove missing values and convert str data to float
    age_list = age_list[1:]  # remove column label
    for i in range(0, len(age_list)):
        if age_list[i] != '':  # skip missing values
            age_list[i] = (float(age_list[i]))
        elif age_list[i] == '':
            age_list[i] = 0.0
    # print("age values: ", str(age_list))

    weight_list = weight_list[1:]
    for i in range(0, len(weight_list)):
        if weight_list[i] != '':  # skip missing values
            weight_list[i] = (float(weight_list[i]))
        elif weight_list[i] == '':
            weight_list[i] = 0.0
    print("weight values: ", str(weight_list))

    height_list = height_list[1:]
    for i in range(0, len(height_list)):
        if height_list[i] != '':  # skip missing values
            height_list[i] = (float(height_list[i]))
        elif height_list[i] == '':
            height_list[i] = 0.0
    print("height values: ", str(height_list))

    print("lengths - ages: ", str(len(age_list)), " heights: ", str(len(height_list)), "weights: ",
          str(len(weight_list)))

    # create dictionary, d, of series
    d = {'PatientId': pd.Series(patient_id_list),
         'Age': pd.Series(age_list),
         'Height': pd.Series(height_list),
         'Weight': pd.Series(weight_list)}

    # measures of central tendency and dispersion for the above chosen attributes.
    # create a data frame, df
    df = pd.DataFrame(d)
    print("df", str(df))

    print("--- \nMeasures of central tendency and dispersion:")
    print("---")
    print("mean values in the distribution: ")
    print(df.mean())

    print("---")
    print("median values in the distribution: ")
    print(df.median())

    print("---")
    print("mode values in the distribution: ")
    print("Age: ", str(mode(age_list)), " Height: ", str(mode(height_list)), " Weight: ", str(mode(weight_list)))
    # print(df.mode())

    print("---")
    print("variance of values in the distribution: ")
    print(df.var())

    print("---")
    print("quartiles in the distribution: ")
    print("Age (years): ")
    print("Q1: ", str(np.quantile(age_list, .25)), " Q3: ", str(np.quantile(age_list, .75)))
    print("-")
    print("Height (metres): ")
    print("Q1: ", str(np.quantile(height_list, .25)), " Q3: ", str(np.quantile(height_list, .75)))
    print("-")
    print("Weight (kilograms): ")
    print("Q1: ", str(np.quantile(weight_list, .25)), " Q3: ", str(np.quantile(weight_list, .75)))

    print("---")
    print("ranges in the distribution:")
    print("Age: ", find_range(age_list), "\n-")
    print("Height: ", find_range(height_list), "\n-")
    print("Weight: ", find_range(weight_list), "\n-")

    # get boxplots for the three attributes
    # get_boxplot(age_list, "Age")
    # get_boxplot(height_list, "Height")
    # get_boxplot(weight_list, "Weight")

    # # get histograms for the attributes
    # get_histogram(age_list, "Age")
    # get_histogram(height_list, "Height")
    # get_histogram(weight_list, "Weight")
    #
    # # get scatter plots for the attributes
    # get_scatter_plot(age_list, "Age")
    # get_scatter_plot(height_list, "Height")
    # get_scatter_plot(weight_list, "Weight")
    #
    # # get z-score norm for the attributes
    # print("--\nz-score normalisation for age: ", str(get_z_scores(age_list)))
    # print("--\nz-score normalisation for height: ", str(get_z_scores(height_list)))
    # print("--\nz-score normalisation for weight: ", str(get_z_scores(weight_list)))

    # get min-max norm for the attributes
    # print("--\nmin-max normalisation for age: ", str(get_min_max_norm(age_list)))
    # print("--\nmin-max normalisation for height: ", str(get_min_max_norm(height_list)))
    # print("--\nmin-max normalisation for weight: ", str(get_min_max_norm(weight_list)))

    # get correlation between attributes
    get_correlation(age_list, "Age", height_list, "Height")  # age vs height
    get_correlation(age_list, "Age", weight_list, "Weight")  # age vs weight
    get_correlation(height_list, "Height", weight_list, "Weight")  # height vs weight

    # end main function
