# eugene casmin 2528933 cng 514 assignment 2
import random


def get_probability_x_c(my_training_set, x,
                        c):  # get p(x|ci), x and c are tuples - (attribute, value). data is the data set.
    # c values are either 'low' or 'high' - our classes
    # x value is a value in the range of attr. values in that column e.g., 'air pollution'
    # e.g., p(air pollution = '3'| risk level = 'low'): count no. of 'low's and count no. of 3's whose risk level is low.

    # data_items = data_set.items  # list of tuples of type (pidN, {col1: val,..., colM: val})

    # change 'medium' to 'high' or 'low'
    high = ['4', '5', '6', '7']
    for this_element in my_training_set:
        if this_element[1]['Level'] == 'Medium':
            if (this_element[1]['Air Pollution'] and this_element[1]['Obesity'] and this_element[1]['Smoking'] and this_element[1]['Coughing of Blood']) in high:
                this_element[1]['Level'] = 'High'
            else:
                this_element[1]['Level'] = 'Low'

    num_x = 0
    num_c = 0

    for this_element in my_training_set:  # e.g., count no. of 'low's
        if this_element[1][c[0]] == c[1]:
            num_c = num_c + 1

    for this_element in my_training_set:  # e.g., count no. of 3's whose risk level is low
        if this_element[1][x[0]] == x[1] and this_element[1][c[0]] == c[1]:
            num_x = num_x + 1

    prob_x_c = float(num_x) / float(num_c)
    # print(f'p({x[0]} => {x[1]}|c => {c[1]}: {prob_x_c}')
    return prob_x_c


def get_probability_c(my_training_set,
                      c):  # returns probability of a value occurring in the distribution of an attribute; c is a tuple (class label, class name)
    # data_items = data_set.items  # list of tuples of type (pidN, {col1: val,..., colM: val})
    occurrences = 0  # to count occurrences of c[1]

    if c[0] == 'Level':
        # change all 'medium' to 'high'
        for this_element in my_training_set:
            if this_element[1]['Level'] == 'Medium':
                if this_element[1]['Air Pollution'] >= 4 and this_element[1]['Obesity'] >= 4 and this_element[1]['Smoking'] >= 4 and this_element[1]['Coughing of Blood'] >= 4:
                    this_element[1]['Level'] = 'High'
                else:
                    this_element[1]['Level'] = 'Low'

    for this_element in my_training_set:
        if this_element[1][c[0]] == c[1]:
            occurrences = occurrences + 1

    prob_c = float(occurrences) / float(len(my_training_set))
    return prob_c


def get_probability_c_tuple(train_set, myTuple, c):  # returns probability of being in class ci given tuple x, p(ci|x).
    # data_set - training set list of patient details, mytuple - dictionary of attribute values {col1: val,..., colM: val}, c - (class label, class name)
    # p(ci|x) = p(x|ci) * p(ci)
    prob_x_ci = get_probability_x_c(train_set, ('Age', myTuple['Age']), c) * get_probability_x_c(train_set, ('Gender', myTuple['Gender']), c) * get_probability_x_c(train_set, ('Air Pollution', myTuple['Air Pollution']), c) * get_probability_x_c(train_set, ('Alcohol use', myTuple['Alcohol use']), c) * get_probability_x_c(train_set, ('chronic Lung Disease', myTuple['chronic Lung Disease']), c) * get_probability_x_c(train_set, ('Obesity', myTuple['Obesity']), c) * get_probability_x_c(train_set, ('Smoking', myTuple['Smoking']), c) * get_probability_x_c(train_set, ('Chest Pain', myTuple['Chest Pain']), c) * get_probability_x_c(train_set, ('Swallowing Difficulty', myTuple['Swallowing Difficulty']), c) * get_probability_x_c(train_set, ('Frequent Cold', myTuple['Frequent Cold']), c) * get_probability_x_c(train_set, ('Snoring', myTuple['Snoring']), c)
    # print(f'p(x => {myTuple}|c => {c[1]}: {prob_x_ci}')
    return prob_x_ci


def classify_tuple(my_training_set,
                   my_tuple):  # takes a tuple (dictionary ds) and returns the probability that it belongs to a certain class.
    # p(ci|x) = p(x|ci) * p(ci)

    # p(x|c = 'Low') * p(c = 'Low') = get_prob_c_x(training_set, element[1], ('Level', 'Low')) * get_prob_c('Risk Level', 'Low')
    c = ('Level', 'Low')
    prob_low = get_probability_c_tuple(my_training_set, my_tuple, c) * get_probability_c(my_training_set, c)

    # p(x|c = 'High') * p(c = 'High') = get_prob_c_x(training_set, element[1], ('Level', 'High')) * get_prob_c('Risk Level', 'High')
    c = ('Level', 'High')
    prob_high = get_probability_c_tuple(my_training_set, my_tuple, c) * get_probability_c(my_training_set, c)

    classification = {'High': prob_high, 'Low': prob_low}

    if classification['High'] >= classification['Low']:
        return 'High'
    else:
        return 'Low'


def run_classifier(data_set_items):
    # call classify_tuple() with all records in the data set.
    # first classify_tuple() argument should be altered with each iteration of classifying
    # training_set - 2/3 of the data_set, test_set - 1/3 of data_set
    # rule for partition indices - arbitrary 1/3 of the data set. 667-1000, 1-333, 333-666,
    # print("records in data_set_items: ", len(data_set_items))
    final_classification_results = []

    # in a loop, randomly gen. 664 unique indices between 0-999 for training set, and 334 which are not in training set.
    for test_count in range(10):
        training_indices = random.sample(range(0, 999), 666)
        # print("training indices: ", len(training_indices), "training indices: ", training_indices)
        test_indices = []

        while len(test_indices) != 334:  # populate test set indices
            my_random_index = random.randint(1, 999)
            # values in test_indices must be unique and different from those in training set.
            if my_random_index not in (training_indices and test_indices):
                test_indices.append(my_random_index)
        # print("test indices: ", len(test_indices), "test indices: ", test_indices)

        # from this point, this should be in a loop until 10 classification runs are completed
        training_set = []  # two thirds for model construction
        for i in range(len(training_indices)):
            training_set.append(list(data_set_items)[training_indices[i]])
        # training_set is a list of tuples containing data of each row i.e., an element is (pid, {col1: val,..., colM:val})
        # print("number of records in training_set: ", len(training_set))

        test_set = []  # one thirds for accuracy estimation
        for i in range(len(test_indices)):
            test_set.append(list(data_set_items)[test_indices[i]])
        # test is a list of tuples containing data of each row i.e., an element is (pid, {col1: val,..., colM:val})
        # print("number of records in test_set: ", len(test_set))

        # taking 'High' prediction as P and 'Low' as N.
        classify_run_results = {'TP': 0, 'FP': 0, 'TN': 0, 'FN': 0}  # result from each test set is a dict {tp: val, tn: val, fp: val, fn: val

        for record in test_set:  # classify each record
            my_class = classify_tuple(training_set, record[1])
            # my_result = (record[0], my_class)

            if my_class == 'High' and (record[1]['Level'] == 'Medium' or record[1]['Level'] == 'High'):
                classify_run_results['TP'] = classify_run_results['TP'] + 1
            elif my_class == 'High' and (record[1]['Level'] == 'Low'):
                classify_run_results['FP'] = classify_run_results['FP'] + 1
            elif my_class == 'Low' and (record[1]['Level'] == 'Low'):
                classify_run_results['TN'] = classify_run_results['TN'] + 1
            elif my_class == 'Low' and (record[1]['Level'] == 'Medium' or record[1]['Level'] == 'High'):
                classify_run_results['FN'] = classify_run_results['FN'] + 1

        # print("classification run", test_count, " result:", classify_run_results)
        final_classification_results.append(classify_run_results)

    print("length of final_classification_results: ", len(final_classification_results))
    return final_classification_results


def analyse_results(classification_results):  # list of dictionaries - confusion matrices from each test run.
    # report confusion matrices & calculate specificity, sensitivity and accuracy for each.

    # in a loop, report results and corresponding specificity, sensitivity and accuracy
    test_counter = 1

    specificities = []
    sensitivities = []
    accuracies = []

    print("---")
    for this_run in classification_results:
        print("Confusion Matrix, ", test_counter, ": ", this_run)
        specificity = float(this_run['TN']) / float(this_run['FP'] + this_run['TN'])
        specificities.append(specificity)

        sensitivity = float(this_run['TP']) / float(this_run['FN'] + this_run['TP'])
        sensitivities.append(sensitivity)

        accuracy = float(this_run['TP'] + this_run['TN']) / float(this_run['FN'] + this_run['TN'] + this_run['FP'] + this_run['TP'])
        accuracies.append(accuracy)

        print(f'Specificity: {specificity}, Sensitivity: {sensitivity}, Accuracy: {accuracy}. \n---')
        test_counter = test_counter + 1

    # take best 7 values for each metric and average them.
    specificities = take_best_seven(specificities)
    sensitivities = take_best_seven(sensitivities)
    accuracies = take_best_seven(accuracies)

    print(f'---\n Aggregate Results: \n Specificity: {float(sum(specificities)) / float(len(specificities))}, Sensitivity: {float(sum(sensitivities)) / float(len(sensitivities))}, Accuracy: {float(sum(accuracies)) / float(len(accuracies))}. \n---')


def take_best_seven(this_list):
    while len(this_list) != 7:
        this_list.remove(min(this_list))

    return this_list


if __name__ == "__main__":
    print("this is the main function.")
    print("to read an csv spreadsheet and convert to dictionary of dictionaries for manipulation..")

    filename = 'cng514-cancer-patient-data.csv'  # to hold excel spreadsheet name plus extension

    with open(filename, newline='') as f:
        csv_list = [[val.strip() for val in r.split(",")] for r in f.readlines()]

    (_, *header), *data = csv_list
    csv_dict = {}
    for row in data:
        key, *values = row
        csv_dict[key] = {key: value for key, value in zip(header, values)}

    # print(csv_dict)

    patient_details = csv_dict  # patient_details is a dict of type {row1: {col1: val, col2: val, ... , colM: val}, ... , rowN: {col1: val, col2: val, ... , colM: val}}

    print("number of records in patient_details: ", len(patient_details))

    # the last field in each record contains the target diagnosis
    # no need to convert numerical data to float because we just need to find the probability of occurrence. we can proceed with strings

    # from this part, we move this to a function called run_classifier that will classify each record n no. of times and return each result to the main function.
    # data preprocessing - since we are using holdout method for accuracy validation, split data into training set and test set in ratio 2:1

    data_set = patient_details.items()
    # print(dict_items)

    # run classifier and return a list of dictionaries of the 10 classification runs.
    results = run_classifier(data_set)
    print("size of results: ", len(results))

    # analyse results
    analyse_results(results)