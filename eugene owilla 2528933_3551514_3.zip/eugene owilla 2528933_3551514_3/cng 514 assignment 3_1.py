# part 1 - association rule mining

import string
import itertools


def convert_string_to_list(a_string):
    characters_to_remove = "[],'"

    new_string = a_string
    for character in characters_to_remove:
        new_string = new_string.replace(character, "")
    this_list = list(new_string.split(" "))

    # convert this_list to list of pairs
    sub_list_size = 2
    sub_list = [this_list[n:n + sub_list_size] for n in range(0, len(this_list), sub_list_size)]
    return sub_list


def all_equal(lst):  # to check if all values in in_sequence are equal
    check = True

    # Comparing each element with 1
    for item in lst:
        if item != 1:
            check = False
            break

    return check


def in_sequence(sequence, item_set):
    # check that all items in item set are in the sequence
    items_in_sequence = []  # to hold items in item set that have been found in the sequence

    for this_item in item_set:
        for this_subsequence in sequence:
            if this_item in this_subsequence:
                # item found, break and check next item in item set
                items_in_sequence.append(this_item)
                break

    # if all items in item set are in the sequence, return true
    if len(item_set) == len(items_in_sequence) and all(item in items_in_sequence for item in item_set):
        return True
    else:
        return False


def get_support(this_data_set, item_set):
    support_count = 0

    if len(item_set) == 1:
        for this_sequence in data_set:
            for this_subsequence in this_sequence:
                if item_set[0] in this_subsequence:
                    support_count = support_count + 1
                    break  # check next subsequence
    else:
        for this_sequence in data_set:  # iterate through data set
            if in_sequence(this_sequence, item_set):
                support_count = support_count + 1

    support = float(support_count) / float(len(this_data_set))

    return support


def get_confidence(this_data_set, item_set):
    # confidence of an item set {A, B, C} = {A -> B, C} = {A, B -> C} = support ({A, B, C}) / support (A).
    confidence = get_support(this_data_set, item_set) / get_support(this_data_set, item_set[0])
    return confidence


def get_sub_sets(my_list):
    sub_sets = [[]]
    for i in range(len(my_list) + 1):
        for j in range(i):
            sub_sets.append(my_list[j: i])

    # retain all subsets of len len(l) - 1
    for this_subset in sub_sets:
        if len(this_subset) > (len(my_list) - 1):
            sub_sets.remove(this_subset)

    return sub_sets


def prune_item_set(k_1_frequent_item_sets, this_item_set):
    # returns true if item set is to be pruned and false if not.

    # we want all items in sub_sets to be in frequent_item_sets
    if all(item in k_1_frequent_item_sets for item in get_sub_sets(this_item_set)):
        return False
    else:
        return True


def remove_redundant_item_sets(item_sets):
    temp_list = []
    duplicate = False

    for item in item_sets:
        if item not in temp_list:  # check that no item set in temp_list has the same items as i
            for temp_list_item in temp_list:
                if all(elem in temp_list_item for elem in item):
                    duplicate = True
                    break

            if not duplicate:  # if no duplicate, add
                temp_list.append(item)
            else:  # reset duplicate check
                duplicate = False

    item_sets = temp_list
    return item_sets


def get_frequent_item_sets(my_data_set, min_support, min_confidence):
    # take data set, support and confidence thresholds and return frequent item sets
    k = 1  # initialise k value to 1
    k_frequent_item_sets = []  # list of lists to hold freq. item sets
    all_frequent_item_sets = {}  # dict. of list of lists to hold all k frequent item sets
    # my_data_set is a list of lists - list of 36 shopping baskets

    all_items = list(itertools.chain.from_iterable(my_data_set))
    print(f'items: {all_items}')

    # create a list of segment labels A-V.
    segment_labels = list(string.ascii_uppercase)[:22]
    print(f'---\nmin_support: {min_support}, min_confidence: {min_confidence} \nsegment_labels: {segment_labels}')

    # generate frequent 1 item sets to start off
    # eliminate infrequent item sets
    for this_item in segment_labels:
        if get_support(my_data_set, this_item) >= min_support:  # no need to check confidence because this is for 1 item sets.
            k_frequent_item_sets.append(this_item)

    all_frequent_item_sets[k] = k_frequent_item_sets

    print(f'---\nk: {k} \n{len(k_frequent_item_sets)} frequent {k}-item sets: {k_frequent_item_sets}')
    # from here, these should be in a loop until we have only one remaining (frequent) item set

    while len(k_frequent_item_sets) > 1:
        k = k + 1  # increment k value
        print(f'---\nk: {k}')

        k_1_frequent_item_sets = k_frequent_item_sets
        k_frequent_item_sets = []  # clear k freq. item sets until we prune and eliminate infreq. k item sets
        item_sets = []

        # generate next (k) freq. item sets by crossing the freq. item sets with each other
        print(f'generating {k}-item sets.')
        for i in range(len(k_1_frequent_item_sets)):
            # merge this freq. item set with all others and add to freq. item sets
            j = i + 1
            while j < len(k_1_frequent_item_sets):
                new_item_set = list(k_1_frequent_item_sets[i])
                new_item_set.extend(item_set for item_set in k_1_frequent_item_sets[j] if item_set not in new_item_set)
                # add new item set to item sets
                item_sets.append(new_item_set)
                j = j + 1

        # remove item sets with length > expected
        new_item_sets = []
        for item_set in item_sets:
            if len(item_set) == k:
                new_item_sets.append(item_set)
        item_sets = new_item_sets

        # remove redundant item sets
        item_sets = remove_redundant_item_sets(item_sets)

        print(f'{len(item_sets)} {k}-item sets generated.')

        # prune supersets with infrequent subsets
        print(f'pruning supersets with infrequent subsets')
        for item_set in item_sets:
            # if item set has a subset that is not among the k-1 freq. item sets, prune this item set
            if prune_item_set(k_1_frequent_item_sets, item_set):
                item_sets.remove(item_set)
        print(f'{len(item_sets)} {k}-item sets after pruning.')
        print(f'{k}-item sets: {item_sets}')

        # eliminate infrequent item sets
        print(f'eliminate infrequent item sets.')
        for this_item_set in item_sets:
            # add item set to frequent item sets if support >= min_support && confidence >= min_confidence
            if get_support(my_data_set, this_item_set) >= min_support and get_confidence(my_data_set, this_item_set) >= min_confidence:
                k_frequent_item_sets.append(this_item_set)

        print(f'{len(k_frequent_item_sets)} frequent {k}-item sets: {k_frequent_item_sets}')
        all_frequent_item_sets[k] = k_frequent_item_sets
        print("---")

    return all_frequent_item_sets


if __name__ == "__main__":
    # read list of lists from txt file
    with open('Babylon_sequence_dataset.txt') as f:
        lines_list = f.readlines()
    # Remove new line characters
    data = [line.strip() for line in lines_list]

    print("data_set: ", data)

    data_set = []  # to hold list of lists

    for this_string in data:
        data_set.append(convert_string_to_list(this_string))

    print("data_set: ", data_set)

    # data_set is now a list of list of lists (list of sequences)
    print(f'number of records in data_set: {len(data_set)}')

    # Apriori algorithm - 1 freq. item sets to n freq. item sets
    frequent_item_sets = get_frequent_item_sets(data_set, 0.75, 0.75)
    print(f'{len(frequent_item_sets)} frequent item sets: {frequent_item_sets}')

    frequent_item_sets = get_frequent_item_sets(data_set, 0.50, 0.75)
    print(f'{len(frequent_item_sets)} frequent item sets: {frequent_item_sets}')